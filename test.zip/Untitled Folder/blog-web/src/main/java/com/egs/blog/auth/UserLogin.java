/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.auth;

import com.egs.blog.backend.entities.User;
import com.egs.blog.backend.services.UserService;
import com.egs.blog.handlers.SessionContext;
import org.apache.log4j.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

/**
 * managed bean for loging user
 * @author eduardm
 */
@ManagedBean(name = "userLogin")
@RequestScoped
public class UserLogin {

    @ManagedProperty("#{userService}")
    private UserService userService;
    @ManagedProperty("#{sessionContext}")
    private SessionContext sessionContext = null;
    private String email;
    private String password;
    private static final Logger logger = Logger.getLogger(UserLogin.class);

    public UserLogin() {
    }

    /**
     * cheching if user with email and password exists
     * if no do nothing
     */
    public String loginUser() {
        User user = userService.userLogin(email, password);
        if (user != null) {
            sessionContext.setUser(user);
            logger.info("user logged in");
            return "home";
        } else {
            logger.error("smthing went wrong");
            return null;
        }
    }

    public void setSessionContext(SessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }
}
