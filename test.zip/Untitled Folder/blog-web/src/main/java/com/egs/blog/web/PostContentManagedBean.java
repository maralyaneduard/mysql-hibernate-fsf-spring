/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.web;

import com.egs.blog.backend.entities.Post;
import com.egs.blog.backend.services.PostService;
import com.egs.blog.utils.ParamUtil;
import org.apache.log4j.Logger;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

/**
 * managed bean for posts
 * @author eduardm
 */
@ManagedBean(name = "postContentManagedBean")
@RequestScoped
public class PostContentManagedBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManagedProperty("#{postService}")
    private PostService postService;
    
    private Post post = null;
    private Long postId;
    private static final Logger logger = Logger.getLogger(PostContentManagedBean.class);

    public PostContentManagedBean() {
    }

    @PostConstruct
    public void init() {
        postId = ParamUtil.longValue(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("postId"));
        post = postService.getPost(postId);
        logger.info("postid - " + postId);
    }

    public PostService getPostService() {
        return postService;
    }

    public void setPostService(PostService postService) {
        this.postService = postService;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }
}
