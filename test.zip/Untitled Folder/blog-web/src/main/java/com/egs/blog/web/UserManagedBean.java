/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egs.blog.web;

import com.egs.blog.backend.entities.User;
import com.egs.blog.backend.services.UserService;
import com.egs.blog.handlers.SessionContext;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
/**
 * managed bean for user delete update
 * also logging out
 * @author eduardm
 */
@ManagedBean(name = "userManagedBean")
@ViewScoped
public class UserManagedBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManagedProperty("#{userService}")
    private UserService userService;
    @ManagedProperty("#{sessionContext}")
    private SessionContext sessionContext = null;
    private User user = null;
    private static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(UserManagedBean.class);

    public UserManagedBean() {
    }

    @PostConstruct
    public void init() {
        user = userService.getUser(sessionContext.getUser().getId());
        System.out.println("User lastname POST " + user.getLastname());
        if (user == null) {
            //redirect/ error page
        }
    }

    public List<User> getUserList() {
        return userService.getUserList(0, 1000);
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public void setSessionContext(SessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    /**
     * sets user to null in session variable
     * @return
     */
    public String logoutUser() {
        sessionContext.setUser(null);
        logger.info("user logged out");
        return "logout";
    }

    /**
     * deletes given user
     * @return
     */
    public String deleteUser() {
        userService.deleteUser(sessionContext.getUser().getId());
        logger.info("user deleted");
        return logoutUser();
    }

    /**
     * updates user
     * @return
     */
    public String updateUser() {
        user.setImageNeme("def.jpg");
        userService.updateUser(user);
        sessionContext.setUser(user);
        logger.info("user updated");
        return "userInfo";
    }
}
