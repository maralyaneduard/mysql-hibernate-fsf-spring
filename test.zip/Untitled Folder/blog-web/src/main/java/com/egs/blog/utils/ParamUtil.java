package com.egs.blog.utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

/**
 * util class
 * @author eduardm
 */
public class ParamUtil {
    /**
     * converts strValue to long
     *
     * @param strValue
     * @return
     */
    static public Long longValue(String strValue) {
        Long reValue = null;
        if ((strValue == null) || (strValue.toString().trim().equals(""))) {
            strValue = null;
        } else if (strValue == null) {
            return null;
        }
        NumberFormat nf = NumberFormat.getInstance();
        try {
            reValue = (Long) nf.parse(strValue).longValue();
        } catch (Exception ex) {
        }
        return reValue;
    }

    /**
     * converts strValue to long
     *
     * @param strValue
     * @return
     */
    static public Long longValue(Object strValue) {
        return longValue((strValue != null) ? strValue.toString() : null);
    }
}