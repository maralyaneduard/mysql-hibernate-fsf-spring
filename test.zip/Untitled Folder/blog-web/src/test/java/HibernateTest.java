/**
 * Created by eduardm
 */

import com.egs.blog.backend.dao.PostDAO;
import com.egs.blog.backend.entities.Post;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.AnnotationConfigWebContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.junit.Assert.assertNotNull;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader = AnnotationConfigWebContextLoader.class,classes = com.egs.blog.backend.configs.CommonCoreConfig.class)
@TransactionConfiguration(defaultRollback=true,transactionManager="transactionManager")
public class HibernateTest {

    @Autowired
    private PostDAO postDAO;

    @Test
    public void testGetPostById() {
        Post post = postDAO.getPostById(13L);

        assertNotNull(post);
    }
}
